# Skeleton Vision Android wrapper

This project packages the existing online site https://my-skeleton.netlify.app in an Android WebView.
It requires internet access. Camera and microphone permissions are requested by Android when the website asks for them.

## Build an APK with GitHub Actions
1. Create a GitHub account (if you do not have one) and a new empty repository.
2. Upload all files in this folder, keeping their folder structure.
3. Open the repository's **Actions** tab.
4. Select **Build Skeleton Vision APK**, then tap **Run workflow**.
5. When the run finishes, open it and download the **Skeleton-Vision-APK** artifact.
6. Extract the downloaded ZIP and install `app-debug.apk` on your Android phone. Allow installation from that source if Android asks.

## Important
- This is an online wrapper, not an offline implementation.
- The skeleton effect itself remains the website's existing feature; this project does not add or repair tracking algorithms.
- The website must remain online for the app to work.
- The APK produced by GitHub Actions is a debug APK, suitable for personal testing, not Play Store release.
